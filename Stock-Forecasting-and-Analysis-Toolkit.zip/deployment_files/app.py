
import gradio as gr
import pandas as pd, numpy as np
def dummy_forecast(model_choice):
    last = 100.0
    days = 7
    df = pd.DataFrame({'date': pd.date_range(start=pd.Timestamp.today()+pd.Timedelta(days=1), periods=days),
                       'predicted_close': (last * (1 + np.random.normal(0,0.01,size=days))).round(2)})
    return df.to_csv(index=False)
with gr.Blocks() as demo:
    gr.Markdown("# DataSynthis_ML_JobTask — Demo")
    model = gr.Radio(['ARIMA','Prophet','LSTM'], value='ARIMA')
    out = gr.Textbox()
    btn = gr.Button("Forecast")
    btn.click(lambda m: dummy_forecast(m), inputs=[model], outputs=[out])
demo.launch()
